package ru.itis.riffloud

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RiffloudApplicationTests {

	@Test
	fun contextLoads() {
	}

}
